//Set year for human
$.datepicker.setDefaults({yearRange:"-110:+0"});