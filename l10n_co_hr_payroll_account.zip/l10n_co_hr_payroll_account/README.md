#Modifica la liquidación de nómina en Odoo para adaptarla a la legislación vigente en Colombia. 
