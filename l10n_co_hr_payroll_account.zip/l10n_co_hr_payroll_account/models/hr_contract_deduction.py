# -*- coding: utf-8 -*-
#/#############################################################################
#
#    Tech-Receptives Solutions Pvt. Ltd.
#    Copyright (C) 2004-TODAY Tech-Receptives(<http://www.techreceptives.com>)
#    Special Credit and Thanks to Thymbra Latinoamericana S.A.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#/#############################################################################
from openerp import models, fields, api

class hr_contract_deduction(models.Model):
    _name = 'hr.contract.deduction'
    _description = 'Deducciones o Pagos Periodicos'

    @api.multi
    def compute_total_accumulated(self):
        hr_payslip_input_obj = self.env['hr.payslip.input']
        for deduction in self:
            total = 0
            for input in hr_payslip_input_obj.search([['contract_id','=',deduction.contract_id.id],['input_id','=',deduction.input_id.id]]):
                if input.payslip_id.state == 'done' and deduction.date <= input.payslip_id.date_to:
                    total += input.amount
            deduction.total_accumulated = total
            
    input_id = fields.Many2one(
    	'hr.rule.input',
    	'Entrada',
    	required = True,
    	help = "Entrada o parametro asociada a la regla salarial")
    type = fields.Selection([
	    	('P','Prestamo Empresa'),
	    	('A','Ahorro'),
	    	('S','Seguro'),
	    	('L','Libranza'),
	    	('E','Embargo'),
	    	('R','Retencion'),
	    	('O','Otros')
    	],'Tipo deduccion',
    	required = True)
    period = fields.Selection([
	    	('limited','Limitado'),
	    	('indefinite','Indefinido')
	    ],'Tipo de Cobro',
        help = "Limitado: Aplicara hasta que se llegue al total establecido, Indefinido: Aplicara indefinidamente",
	    required = True)
    amount = fields.Float(
    	'Valor',
    	help="Valor de la cuota o porcentaje segun formula de la regla salarial",
    	required = True)
    total_deduction = fields.Float(
    	'Total',
    	help = "Total a Descontar")
    total_accumulated = fields.Float(
        'Acumulado',
        compute = 'compute_total_accumulated',
        help = "Total pagado o acumulado del concepto",
        readonly = True)
    date = fields.Date(
    	'Fecha Inicio',
    	select = True,
    	help="Fecha del prestamo u obligacion",
        required = True)
    contract_id = fields.Many2one(
    	'hr.contract',
    	'Deduciones',
    	required = True,
    	ondelete='cascade',
    	select=True)
    final = fields.Boolean(
        'Finalizado',
        help = "Marcar si la deduccion u obligacion a finalizado")

    _defaults = {
        'type': "O",
        'period': "indefinite",
        'amount' : 0.00,
        'final': False,
    }