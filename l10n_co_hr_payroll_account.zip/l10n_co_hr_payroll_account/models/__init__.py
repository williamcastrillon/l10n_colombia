# -*- coding: utf-8 -*-
import hr_payslip_input
import hr_payroll_structure
import hr_contract_deduction
import hr_contract_risk
import hr_contract
import hr_employee
import hr_salary_rule
import hr_payslip

