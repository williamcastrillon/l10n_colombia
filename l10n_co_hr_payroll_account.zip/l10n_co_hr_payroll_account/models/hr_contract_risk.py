# -*- coding: utf-8 -*-
#/#############################################################################
#
#    Tech-Receptives Solutions Pvt. Ltd.
#    Copyright (C) 2004-TODAY Tech-Receptives(<http://www.techreceptives.com>)
#    Special Credit and Thanks to Thymbra Latinoamericana S.A.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#/#############################################################################
from openerp import models, fields

class hr_contract_risk(models.Model):
    _name= 'hr.contract.risk'
    _description = 'Riesgos Profesionales'
    
    code = fields.Char(
        string = 'Codigo',
        size=10,
        required = True)
    name = fields.Char(
        string = 'Nombre',
        size=100,
        required = True)
    percent = fields.Float(
        string = 'Porcentaje',
        required = True,
        help="Porcentaje del riesgo profesional")
    date = fields.Date('Fecha vigencia')
    
    _defaults = {
      'percent' : 0.00,          
    }